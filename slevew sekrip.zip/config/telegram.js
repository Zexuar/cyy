module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "7900418778:AAGKZ0HsKdgXK2StwTgWzP9Pp2aD-MqMvy0",
  OWNER_ID: process.env.OWNER_ID || 7816220387,
  ID_GROUP: [
    -1002351923735
  ],
  ID_GROUP_UTAMA: [
    -1002351923735
  ]
};