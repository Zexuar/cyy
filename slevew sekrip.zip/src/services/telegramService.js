const TelegramBot = require("node-telegram-bot-api");
const { logger } = require('../utils/logger');
const { TOKEN, OWNER_ID, ALLOWED_GROUPS } = require('../config/telegram'); 
const axios = require("axios");
const { loadDatabase, saveDatabase } = require('./databaseServis');
// ALLOWED_GROUPS = array of allowed group IDs, contoh: [-1001234567890, -1009876543210]

// =====================
// GITHUB CONFIG
// =====================

const GITHUB_TOKEN = "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";
const REPO_OWNER = "Zexuar";
const REPO_NAME = "Db-script";
const FILE_PATH = "Aeternyx.json";
const BRANCH = "main";

const API =
`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`;

const bot = new TelegramBot(TOKEN, { polling: true });

// Fungsi helper untuk cek akses
function hasAccess(chatId) {
  // Bisa akses kalau private chat atau grup yang diijinkan
  return chatId > 0 || ALLOWED_GROUPS.includes(chatId);
}

async function getGithubFile(){
 const res = await axios.get(API,{
 headers:{
 Authorization:`token ${GITHUB_TOKEN}`
 }
 });

 const content = Buffer
 .from(res.data.content,"base64")
 .toString("utf8");

 return {
 sha:res.data.sha,
 data:JSON.parse(content || "[]")
 };
}

async function updateGithubFile(
 data,
 sha,
 message
){

 const content = Buffer
 .from(JSON.stringify(data,null,2))
 .toString("base64");

 await axios.put(API,{
 message,
 content,
 sha,
 branch:BRANCH
 },{
 headers:{
 Authorization:`token ${GITHUB_TOKEN}`
 }
 });
}

// Command /start atau /menu
bot.onText(/^\/?(start|menu)/, (msg) => {
  const chatId = msg.chat.id;
  const isOwner = msg.from.id === OWNER_ID;

  if (!hasAccess(chatId)) {
    return bot.sendMessage(chatId, "❌ Maaf, grup/privatemu tidak diijinkan.");
  }

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Bikin acc member", callback_data: "create_member" }],
        [{ text: "⏳ Set Exp", callback_data: "set_expire" }],

 [{text:"🔑 Add Token",callback_data:"panel|addtoken"},

 {text:"🗑 Delete Token",callback_data:"panel|deltoken"}],
        ...(isOwner ? [[
          { text: "📋 List Acc", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(chatId, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});

// Callback query
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const data = query.data;
  const isOwner = userId === OWNER_ID;

  if (!hasAccess(chatId)) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Grup tidak diizinkan." });
  }
  
  function getUserRole(id){

 const db = loadDatabase();

 const user = db.find(
 u => Number(u.telegramId) === Number(id)
 );

 return user?.role || null;

}

    if(data.startsWith("panel|")){

const action =
data.split("|")[1];

const role =
getUserRole(userId);


// =================
// ADD PARTNER
// =================

// ADD PARTNER
if(action==="addpartner"){

 if(!isOwner){

 return bot.sendMessage(
 chatId,
 "❌ Owner only."
 );

 }

 bot.sendMessage(
 chatId,
 "Reply pesan user target."
 );

 bot.once("message",(msg)=>{

 if(!msg.reply_to_message){

 return bot.sendMessage(
 chatId,
 "❌ Harus reply user."
 );

 }

 const target =
 msg.reply_to_message.from.id;

 const db =
 loadDatabase();

 if(db.find(
 u=>Number(u.telegramId)===Number(target)
 )){

 return bot.sendMessage(
 chatId,
 "❌ Sudah punya role."
 );

 }

 db.push({

 telegramId:target,
 role:"partner"

 });

 saveDatabase(db);

 bot.sendMessage(
 chatId,
 "✅ Partner berhasil ditambah."

 );

 });

}


// =================
// ADD RESELLER
// =================

else if(action==="addreseller"){

 if(!isOwner && role!=="partner"){

 return bot.sendMessage(
 chatId,
 "❌ Owner / Partner only."
 );

 }

 bot.sendMessage(
 chatId,
 "Reply pesan user target."
 );

 bot.once("message",(msg)=>{

 if(!msg.reply_to_message){

 return bot.sendMessage(
 chatId,
 "❌ Harus reply user."
 );

 }

 const target =
 msg.reply_to_message.from.id;

 const db =
 loadDatabase();

 db.push({

 telegramId:target,
 role:"reseller"

 });

 saveDatabase(db);

 bot.sendMessage(
 chatId,
 "✅ Reseller berhasil ditambah."

 );

 });

}


// =================
// ADD TOKEN
// =================

else if (action === "addtoken") {

 if (!isOwner && role !== "reseller") {

  return bot.sendMessage(
   chatId,
   "❌ Reseller only."
  );

 }

 await bot.sendMessage(
  chatId,
  "Masukkan TOKEN:"
 );

 const listener = async (msg) => {

  // hanya user ini
  if (msg.from.id !== userId) return;

  // hanya chat ini
  if (msg.chat.id !== chatId) return;

  // cek text
  if (!msg.text) return;

  const token = msg.text.trim();

  try {

   const file =
    await getGithubFile();

   let db = file.data;

   // safety object
   if (!db || typeof db !== "object") {

    db = { tokens: [] };

   }

   // kalau tokens ga ada
   if (!Array.isArray(db.tokens)) {

    db.tokens = [];

   }

   // add token
   db.tokens.push(token);

   await updateGithubFile(

    db,
    file.sha,
    "Add Token"

   );

   await bot.sendMessage(
    chatId,
    "✅ Token berhasil ditambah."
   );

  } catch (e) {

   console.log(e);

   await bot.sendMessage(
    chatId,
    "❌ Error add token."
   );

  }

  // remove listener biar ga spam
  bot.removeListener(
   "message",
   listener
  );

 };

 bot.on("message", listener);

}


// =================
// DELETE TOKEN
// =================

else if(action==="deltoken"){

 if(!isOwner && role!=="reseller"){

 return bot.sendMessage(
 chatId,
 "❌ Reseller only."
 );

 }

 bot.sendMessage(
 chatId,
 "Masukkan TOKEN yang mau dihapus:"
 );

 const listener = async(msg)=>{

 // cuma user ini
 if(msg.from.id !== userId) return;

 // cuma chat ini
 if(msg.chat.id !== chatId) return;

 const token =
 msg.text.trim();

 try{

 const file =
 await getGithubFile();

 let db =
 file.data;

 // pastikan object
 if(typeof db !== "object" || Array.isArray(db)){

 db = {tokens:[]};

 }

 // pastikan tokens array
 if(!Array.isArray(db.tokens)){

 db.tokens = [];

 }

 const index =
 db.tokens.indexOf(token);

 if(index === -1){

 bot.sendMessage(
 chatId,
 "❌ Token tidak ditemukan."
 );

 return bot.removeListener(
 "message",
 listener
 );

 }

 db.tokens.splice(
 index,
 1
 );

 await updateGithubFile(

 db,
 file.sha,
 "Delete Token"

 );

 bot.sendMessage(
 chatId,
 "🗑 Token berhasil dihapus."
 );

 }catch(e){

 console.log(e);

 bot.sendMessage(
 chatId,
 "❌ Error delete token."
 );

 }

 // remove listener
 bot.removeListener(
 "message",
 listener
 );

 };

 bot.on(
 "message",
 listener
 );

}
}

  switch (data) {
    case "create_member":
      bot.sendMessage(chatId, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(chatId, "❌ Username sudah ada.");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(chatId, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(chatId, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(chatId, "❌ User tidak ditemukan.");

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(chatId, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(chatId, `📋 *Daftar Pengguna:*\n${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(chatId, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(chatId, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(chatId, `✅ Akun ${role} dibuat:
👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(chatId, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(chatId, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(chatId, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

// Helper
function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

function startTelegramBot() {
  console.log("Telegram bot started");
}

module.exports = 
{ 
bot,
startTelegramBot
};