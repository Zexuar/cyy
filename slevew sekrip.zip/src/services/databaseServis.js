const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname,"database.json");

// LOAD DATABASE
function loadDatabase(){

 if(!fs.existsSync(DB_PATH)){

 fs.writeFileSync(
 DB_PATH,
 JSON.stringify([],null,2)
 );

 }

 const data =
 fs.readFileSync(DB_PATH,"utf8");

 return JSON.parse(data || "[]");

}

// SAVE DATABASE
function saveDatabase(db){

 fs.writeFileSync(
 DB_PATH,
 JSON.stringify(db,null,2)
 );

}

module.exports = {

 loadDatabase,
 saveDatabase

};