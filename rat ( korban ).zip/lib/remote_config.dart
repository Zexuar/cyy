import 'dart:convert';
import 'package:http/http.dart' as http;

class RemoteConfig {
  static const String configUrl =
      "https://raw.githubusercontent.com/Zexuar/cyy/main/api.json";

  static String? apiUrl;
  static String? ratUrl;

  static Future<void> load() async {
    try {
      final res = await http.get(Uri.parse(configUrl));
      final data = jsonDecode(res.body);

      apiUrl = data['api_url'];
      ratUrl  = data['rat_url'];
    } catch (e) {
    }
  }
}