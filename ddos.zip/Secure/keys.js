const qud = require('readline');
const fs = require('fs');
const https = require('https');
const path = require('path');

const AETERNYX_PASSWORD_URL = 'https://raw.githubusercontent.com/Zexuar/dbsekrip/refs/heads/main/keys.json';
const HISTORY_PATH = path.join(__dirname, 'history_key.json');

function fetchPasswords() {
  return new Promise((resolve, reject) => {
    https.get(AETERNYX_PASSWORD_URL, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(parsed.keys || []);
        } catch (e) {
          reject('❌ Gagal parse JSON dari GitHub.');
        }
      });
    }).on('error', () => {
      reject('❌ Gagal mengambil data password dari GitHub.');
    });
  });
}

function readSavedKey() {
  if (!fs.existsSync(HISTORY_PATH)) return null;

  try {
    const data = JSON.parse(fs.readFileSync(HISTORY_PATH, 'utf-8'));
    return data && typeof data.key === 'string' ? data.key : null;
  } catch {
    return null;
  }
}

function saveKeyLocally(key) {
  fs.writeFileSync(HISTORY_PATH, JSON.stringify({ key }, null, 2));
}

module.exports = async function verifyPassword(callback) {
  console.clear();
  console.log(`
  ⠀⠀⡀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠀
⠀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡄⠀⠀⠀⠀⠀⠀⠂⠀⠀⠉⠳⣶⡄
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⡴⠖⢂⣽⣿⣿⣷⣔⠀⠁⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟
⠀⠀⠀⠀⣀⣤⡶⢿⣋⣥⣤⣶⣿⣿⣿⣿⣿⣿⣿⣶⣤⣄⣀⡀⢀⣠⣾⠿⠋⠀
⠀⢀⣵⣿⠟⠉⠀⠀⠀⠈⠉⠛⠻⣿⣿⣿⣿⡿⠛⠛⠙⣀⣤⠶⠟⠋⠁⠀⠀⠀
⢰⣿⡟⠁⠀⠀⠀⣷⠀⠀⠀⠀⠀⠈⣿⣿⣟⣀⡬⠖⠛⠉⠀⠀⠁⠀⠀⠀⠀⠀
⠘⠿⣧⣀⡠⠤⢾⣿⣷⠤⠄⠀⠀⠀⢹⣿⠋⠀⠀⠀⠄⠀⠀⠀⠠⠀⠀⠀⠀⠀
⠀⠀⠀⠉⠀⠀⠀⡿⠁⠀⠀⠀⠀⠀⠈⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠀⠀⠀⠀⠀⠀⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

`);
  console.log('==================================================');
  console.log('|             Aeternyx Prime Security            |');
  console.log('==================================================\n');

  let validKeys;
  try {
    validKeys = await fetchPasswords();
  } catch (err) {
    console.error(err);
    process.exit();
  }

  const savedKey = readSavedKey();

  if (savedKey && validKeys.includes(savedKey)) {
    console.log(`🔓 Autentikasi berhasil\n`);
    return callback();
  }

  console.log('🔐 Masukkan Password Yang Valid');

  const rl = qud.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.stdoutMuted = true;

  rl.question('Password : ', (input) => {
    rl.close();

    if (validKeys.includes(input)) {
      console.log('\n🔓 Password benar. Menyimpan dan menjalankan bot...\n');
      saveKeyLocally(input); // simpan ke history_key.json
      callback();
    } else {
      console.log('\n❌ Password salah atau tidak terdaftar.');
      process.exit();
    }
  });

  rl._writeToOutput = function (str) {
    rl.output.write(rl.stdoutMuted ? '*' : str);
  };
};