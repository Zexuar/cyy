const keyyyyy = require('./Secure/keys.js');

keyyyyy(() => {
const { spawn } = require('child_process');
const readline = require('readline');
const path = require('path');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function mainMenu() {
    console.clear();
    console.log(`
   \x1b[1;37m =====================================
   \x1b[1;31m    XANVERIUS C2 COMMAND CENTER
   \x1b[1;37m =====================================
       [1] \x1b[1;32mLayer 4 - GAMES LAG (Python)
       [2] \x1b[1;36mLayer 7 - WEBSITE LAG(Node.js)
       [0] \x1b[1;31mExit
   \x1b[1;37m =====================================
    \x1b[0m`);

    rl.question('\x1b[1;37mxanverius@c2:~$ \x1b[0m', (choice) => {
        if (choice === '1') {
            console.log("\n\x1b[1;33m[!] Switching to L4 Python Engine...\x1b[0m");
            // Oper kontrol ke Python
            const l4Path = path.join(__dirname, 'lib', 'engine', 'l4.py');
            const l4 = spawn('python3', [l4Path], { stdio: 'inherit' });
            
            l4.on('close', () => {
                console.log("\n\x1b[1;37m[!] Back to Master Controller...\x1b[0m");
                setTimeout(mainMenu, 1500);
            });

        } else if (choice === '2') {
            console.log("\n\x1b[1;33m[!] Switching to L7 Node.js Engine...\x1b[0m");
            // Oper kontrol ke index.js
            const l7Path = path.join(__dirname, 'lib', 'engine', 'l7.js');
            const l7 = spawn('node', [l7Path], { stdio: 'inherit' });

            l7.on('close', () => {
                console.log("\n\x1b[1;37m[!] Back to Master Controller...\x1b[0m");
                setTimeout(mainMenu, 1500);
            });

        } else if (choice === '0') {
            console.log("\x1b[1;31mGoodbye, XANVERIUS.\x1b[0m");
            process.exit();
        } else {
            mainMenu();
        }
    });
}

mainMenu();
});