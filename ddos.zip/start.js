const keyyyyy = require('./Secure/keys.js');
const os = require('os'); 

keyyyyy(() => {
    const { spawn } = require('child_process');
    const readline = require('readline');
    const path = require('path');

    // Kita buat fungsi untuk generate interface agar bisa dibuka-tutup
    function createRl() {
        return readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
    }

    let rl = createRl();

    function checkSystemStability(callback) {
        const freeRam = os.freemem() / 1024 / 1024; 
        const loadAvg = os.loadavg()[0]; 
        const cpuCount = os.cpus().length;

        const MIN_RAM_MB = 200; 
        const MAX_LOAD_RATIO = 0.80; 

        const isUnstable = (freeRam < MIN_RAM_MB || (loadAvg / cpuCount) > MAX_LOAD_RATIO);

        if (isUnstable) {
            console.log(`\n\x1b[1;41m [!] PERINGATAN: SISTEM TIDAK STABIL [!] \x1b[0m`);
            console.log(`\x1b[1;31m RAM Sisa  : ${freeRam.toFixed(0)} MB`);
            console.log(`\x1b[1;31m CPU Load  : ${(loadAvg / cpuCount * 100).toFixed(0)}%\x1b[0m`);
            console.log(`\x1b[1;33m Menjalankan script dalam kondisi ini dapat menyebabkan perangkat anda FREEZE/DIE, dan bisa membuat peforma script menurun.`);
            console.log(`-By t.me/biyalue2\x1b[0m`);
            
            console.log(`\n\x1b[1;37m Tetap lanjutkan? (yes/no): \x1b[0m`);
            rl.question(`\n\x1b[1;37m Jawaban: \x1b[0m`, (ans) => {
                if (ans.toLowerCase() === 'yes') {
                    console.log(`\x1b[1;32m[+] Melanjutkan...\x1b[0m`);
                    // TUTUP RL sebelum masuk ke engine agar stdio:inherit lancar
                    rl.close(); 
                    setTimeout(callback, 500);
                } else {
                    console.log(`\x1b[1;31m[!] Aborting. Goodbye.\x1b[0m`);
                    process.exit();
                }
            });
        } else {
            // Jika stabil pun, TUTUP RL sebelum callback (masuk ke engine)
            rl.close();
            callback();
        }
    }

    function mainMenu() {
        // Pastikan rl terbuka saat di menu utama
        if (rl.line === undefined) rl = createRl(); 
        
        console.clear();
        console.log(`
   \x1b[1;37m =====================================
   \x1b[1;31m    XANVERIUS COMMAND CENTER
   \x1b[1;37m =====================================
       [1] \x1b[1;32mLayer 4 - GAMES LAG
       [2] \x1b[1;36mLayer 7 - WEBSITE LAG
       [0] \x1b[1;31mExit
   \x1b[1;37m =====================================
    \x1b[0m`);

        rl.question('\x1b[1;37mxanverius@c2:~$ \x1b[0m', (choice) => {
            if (choice === '1' || choice === '2') {
                const protocolName = choice === '1' ? "L4 Engine" : "L7 Engine";
                
                checkSystemStability(() => {
                    console.log(`\n\x1b[1;33m[!] Switching to ${protocolName}...\x1b[0m`);
                    
                    let engine;
                    if (choice === '1') {
                        const l4Path = path.join(__dirname, 'lib', 'engine', 'l4.py');
                        engine = spawn('python3', [l4Path], { stdio: 'inherit' });
                    } else {
                        const l7Path = path.join(__dirname, 'lib', 'engine', 'l7.js');
                        engine = spawn('node', [l7Path], { stdio: 'inherit' });
                    }

                    engine.on('close', () => {
                        console.log("\n\x1b[1;37m[!] Back to Master Controller...\x1b[0m");
                        // Buka kembali rl untuk menu utama
                        rl = createRl(); 
                        setTimeout(mainMenu, 1000);
                    });
                });

            } else if (choice === '0') {
                console.log("\x1b[1;31mGoodbye, XANVERIUS.\x1b[0m");
                process.exit();
            } else {
                mainMenu();
            }
        });
    }

    mainMenu();
});