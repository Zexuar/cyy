const axios = require('axios');
const fs = require('fs');
const inquirer = require('inquirer');
const chalk = require('chalk');
const { SocksProxyAgent } = require('socks-proxy-agent');
const http = require('http');

// Global variables untuk menyimpan data secara real-time
let alive = [];
let deadCount = 0;
let rawProxies = [];
let selectedTypes = [];
let isExiting = false;

const SOURCES = {
    http: [
        'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
        'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt'
    ],
    socks4: [
        'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt',
        'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt'
    ],
    socks5: [
        'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
        'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt',
        'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt'
    ]
};

// Fungsi Save Otomatis
function forceSave() {
    if (isExiting) return;
    isExiting = true;

    console.log(chalk.red.bold('\n\n[!] MENDETEKSI CTRL+C (PAKSA BERHENTI)...'));
    
    if (alive.length === 0) {
        console.log(chalk.yellow('[!] Tidak ada proxy yang hidup untuk disimpan. Mematikan sistem...'));
        process.exit();
    }

    const now = new Date();
    const dateStr = `${now.getDate()}-${now.getMonth() + 1}-${now.getFullYear()}`;
    const timeStr = `${now.getHours()}.${now.getMinutes()}`;

    console.log(chalk.blue(`[*] Menyimpan ${alive.length} proxy yang sudah ditemukan sebelum keluar...`));

    selectedTypes.forEach(type => {
        const filtered = alive.filter(p => p.type === type).map(p => p.ip);
        if (filtered.length > 0) {
            const fileName = `${type}_EMERGENCY_${dateStr}_${timeStr}.txt`;
            fs.writeFileSync(fileName, filtered.join('\n'));
            console.log(chalk.cyan(`[SAVED] ${fileName}`));
        }
    });

    console.log(chalk.magenta('\n================ LOG TERAKHIR ================'));
    console.log(chalk.green(` TOTAL ALIVE : ${alive.length}`));
    console.log(chalk.red(` TOTAL DEAD  : ${deadCount}`));
    console.log(chalk.magenta('=============================================='));
    console.log(chalk.yellow('Sistem dimatikan dengan aman. Bye!\n'));
    process.exit();
}

// Tangkap Sinyal Ctrl+C
process.on('SIGINT', forceSave);

async function checkProxy(proxy, type) {
    return new Promise((resolve) => {
        const [host, port] = proxy.split(':');
        let agent;
        try {
            if (type === 'http') {
                agent = new http.Agent({ host, port, timeout: 3000 });
            } else {
                agent = new SocksProxyAgent(`${type}://${proxy}`);
            }
            const req = http.get({
                host: 'httpbin.org',
                path: '/ip',
                agent: agent,
                timeout: 3000
            }, (res) => {
                if (res.statusCode === 200) resolve(true);
                else resolve(false);
            });
            req.on('error', () => resolve(false));
            req.on('timeout', () => { req.destroy(); resolve(false); });
        } catch (e) { resolve(false); }
    });
}

// Custom prompt agar Android friendly (p = pilih, a = semua)
const Checkbox = require('inquirer/lib/prompts/checkbox');
class AndroidCheckbox extends Checkbox {
    onKeypress(e) {
        if (e.key.name === 'p') e.key.name = 'space';
        if (e.key.name === 'a') {
            this.choices.forEach(c => { if (c.type !== 'separator') c.checked = true; });
            this.render(); return;
        }
        super.onKeypress(e);
    }
}
inquirer.registerPrompt('android-checkbox', AndroidCheckbox);

async function main() {
    console.clear();
    console.log(chalk.magenta.bold('=============================================='));
    console.log(chalk.magenta.bold('    PROXY SCRAPER & CHECKER BY XANVERIUS       '));
    console.log(chalk.magenta.bold('==============================================\n'));

    const answers = await inquirer.prompt([
        {
            type: 'android-checkbox',
            name: 'types',
            message: 'Pilih tipe proxy:',
            choices: [{ name: 'HTTP', value: 'http' }, { name: 'SOCKS4', value: 'socks4' }, { name: 'SOCKS5', value: 'socks5' }]
        },
        {
            type: 'input',
            name: 'threads',
            message: 'Jumlah thread checking:',
            default: '200'
        }
    ]);

    selectedTypes = answers.types;
    const startTime = Date.now();

    console.log(chalk.blue('\n[*] Scraping data...'));
    for (const type of selectedTypes) {
        for (const url of SOURCES[type]) {
            try {
                const res = await axios.get(url);
                const list = res.data.split('\n').filter(p => p.includes(':')).map(p => ({ ip: p.trim(), type }));
                rawProxies = [...rawProxies, ...list];
            } catch (e) {}
        }
    }

    rawProxies = Array.from(new Set(rawProxies.map(p => JSON.stringify(p)))).map(p => JSON.parse(p));
    console.log(chalk.white(`[+] Total unik: ${rawProxies.length}`));
    console.log(chalk.yellow(`[!] Tekan Ctrl+C kapan saja untuk simpan hasil sementara.\n`));

    const runChunk = async (proxies) => {
        for (const p of proxies) {
            if (isExiting) break; // Berhenti jika Ctrl+C ditekan
            if (await checkProxy(p.ip, p.type)) {
                alive.push(p);
                console.log(chalk.green(` [ALIVE] [${p.type.toUpperCase()}] ${p.ip}`));
            } else { deadCount++; }
        }
    };

    const chunkSize = Math.ceil(rawProxies.length / parseInt(answers.threads));
    const chunks = [];
    for (let i = 0; i < rawProxies.length; i += chunkSize) chunks.push(rawProxies.slice(i, i + chunkSize));
    
    await Promise.all(chunks.map(c => runChunk(c)));

    // Jika selesai normal tanpa Ctrl+C
    if (!isExiting) {
        const endTime = Date.now();
        console.log(chalk.magenta('\n=============================================='));
        console.log(chalk.green(` ALIVE: ${alive.length} | DEAD: ${deadCount}`));
        console.log(chalk.yellow(` SCAN SELESAI DALAM ${((endTime - startTime)/1000).toFixed(2)}s`));
        console.log(chalk.magenta('=============================================='));

        selectedTypes.forEach(type => {
            const filtered = alive.filter(p => p.type === type).map(p => p.ip);
            if (filtered.length > 0) {
                const now = new Date();
                const fileName = `${type}_FINAL_${now.getDate()}-${now.getMonth()+1}.txt`;
                fs.writeFileSync(fileName, filtered.join('\n'));
                console.log(chalk.cyan(`[SAVED] ${fileName}`));
            }
        });
        process.exit();
    }
}

main().catch(err => console.error(err));
