const axios = require('axios');
const fs = require('fs');
const chalk = require('chalk');
const { SocksProxyAgent } = require('socks-proxy-agent');
const http = require('http');
const https = require('https');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

// Config Axios Turbo
const axiosInstance = axios.create({
    httpsAgent: new https.Agent({ rejectUnauthorized: false }),
    timeout: 10000,
    headers: { 
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' 
    }
});

let alive = [];
let deadCount = 0;
let rawProxies = [];
let selectedTypes = [];
let checkedCount = 0;
let isExiting = false;

// DATABASE SUMBER - 50+ LINKS
const SOURCES = {
    http: [
        'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
        'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
        'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all',
        'https://raw.githubusercontent.com/officialputuid/Proxy-List/master/http.txt',
        'https://raw.githubusercontent.com/skydropx/proxy-list/master/http.txt',
        'https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt',
        'https://raw.githubusercontent.com/rooster127/proxy-list/main/http.txt',
        'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt',
        'https://raw.githubusercontent.com/Zaeem20/proxy-list/master/http.txt',
        'https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt',
        'https://raw.githubusercontent.com/Anonym7seven/Proxy-List/main/http.txt',
        'https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt',
        'https://raw.githubusercontent.com/sunny9581/proxy-list/master/proxy.txt',
        'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt',
        'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt'
    ],
    socks4: [
        'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt',
        'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt',
        'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=10000',
        'https://raw.githubusercontent.com/rooster127/proxy-list/main/socks4.txt',
        'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt',
        'https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt',
        'https://raw.githubusercontent.com/Zaeem20/proxy-list/master/socks4.txt',
        'https://raw.githubusercontent.com/B4RC0DE-711/proxy-list/main/SOCKS4.txt',
        'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks4.txt'
    ],
    socks5: [
        'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
        'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt',
        'https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000',
        'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
        'https://raw.githubusercontent.com/rooster127/proxy-list/main/socks5.txt',
        'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt',
        'https://raw.githubusercontent.com/manuGMG/proxy-365/main/SOCKS5.txt',
        'https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt',
        'https://raw.githubusercontent.com/Zaeem20/proxy-list/master/socks5.txt',
        'https://raw.githubusercontent.com/B4RC0DE-711/proxy-list/main/SOCKS5.txt',
        'https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/socks5.txt',
        'https://raw.githubusercontent.com/officialputuid/Proxy-List/master/socks5.txt',
        'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt',
        'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks5.txt',
        'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt',
        'https://raw.githubusercontent.com/Zeyad-2/Proxy-List/main/socks5.txt',
        'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/socks5/data.txt'
    ]
};

function showStatistics(isEmergency = false) {
    if (isExiting) return;
    isExiting = true;
    console.log(chalk.magenta.bold('\n\n=============================================='));
    console.log(chalk.white.bold(isEmergency ? '    STOP PAKSA - DATA DIKUNCI' : '    SCAN SELESAI - STATISTIK'));
    console.log(chalk.magenta.bold('=============================================='));
    console.log(chalk.white(` [+] Total Scraped   : `) + chalk.yellow(rawProxies.length));
    console.log(chalk.white(` [+] Berhasil Dicek  : `) + chalk.cyan(checkedCount));
    console.log(chalk.green(` [+] Alive (Hidup)   : `) + chalk.green.bold(alive.length));
    console.log(chalk.red(` [+] Dead (Mati)     : `) + chalk.red(deadCount)); // FIX BUG STATS
    console.log(chalk.magenta.bold('=============================================='));

    const now = new Date();
    const dateStr = `${now.getDate()}-${now.getMonth()+1}`;
    selectedTypes.forEach(type => {
        const filtered = alive.filter(p => p.type === type).map(p => p.ip);
        if (filtered.length > 0) {
            const name = `${type}_${dateStr}.txt`;
            fs.writeFileSync(name, filtered.join('\n'));
            console.log(chalk.cyan(` [!] Saved: ${name} (${filtered.length} IP)`));
        }
    });
    process.exit();
}

process.on('SIGINT', () => showStatistics(true));

async function checkProxy(proxy, type) {
    return new Promise((resolve) => {
        const [host, port] = proxy.split(':');
        let agent;
        try {
            if (type === 'http') agent = new http.Agent({ host, port, timeout: 3000 });
            else agent = new SocksProxyAgent(`${type}://${proxy}`);
            
            const req = http.get({ 
                host: 'httpbin.org', 
                path: '/ip', 
                agent: agent, 
                timeout: 3000 
            }, (res) => {
                if (res.statusCode === 200) resolve(true);
                else resolve(false);
            });
            req.on('error', () => resolve(false));
            req.on('timeout', () => { req.destroy(); resolve(false); });
        } catch (e) { resolve(false); }
    });
}

async function startChecking(concurrency = 400) {
    console.log(chalk.yellow(`[*] Memulai Scan dengan ${concurrency} Threads...\n`));
    const queue = [...rawProxies];
    
    const worker = async () => {
        while (queue.length > 0 && !isExiting) {
            const p = queue.shift();
            if (!p) continue;
            
            const isAlive = await checkProxy(p.ip, p.type);
            checkedCount++;
            
            if (isAlive) {
                alive.push(p);
                console.log(chalk.green(` [ALIVE] [${p.type.toUpperCase()}] ${p.ip}`));
            } else {
                deadCount++; // FIX: Tambahkan counter dead
            }
            process.stdout.write(chalk.gray(` Progress: ${checkedCount}/${rawProxies.length} | Alive: ${alive.length} \r`));
        }
    };

    const workers = Array(Math.min(concurrency, queue.length)).fill(null).map(() => worker());
    await Promise.all(workers);
    showStatistics();
}

async function startScraping() {
    console.log(chalk.blue(`\n[*] Menghubungi 50+ Sumber...`));
    for (const type of selectedTypes) {
        for (const url of SOURCES[type]) {
            try {
                process.stdout.write(chalk.gray(` [>] Fetch: ${url.substring(0, 40)}...\r`));
                const res = await axiosInstance.get(url);
                const matches = res.data.match(/\d+\.\d+\.\d+\.\d+:\d+/g);
                if (matches) {
                    matches.forEach(ip => rawProxies.push({ ip, type }));
                }
            } catch (e) { /* Skip error link */ }
        }
    }

    // Buang Duplikat
    const seen = new Set();
    rawProxies = rawProxies.filter(p => {
        const duplicate = seen.has(p.ip);
        seen.add(p.ip);
        return !duplicate;
    });

    console.log(chalk.green(`\n[+] Berhasil mengumpulkan ${rawProxies.length} IP unik.`));
    
    if (rawProxies.length === 0) {
        console.log(chalk.red(`[!] 0 IP? Cek koneksi atau coba tipe lain.`));
        process.exit();
    }

    rl.question(chalk.yellow('Thread (300-800): '), (t) => {
        startChecking(parseInt(t) || 400);
    });
}

// MENU UTAMA
console.clear();
console.log(chalk.magenta.bold('=============================================='));
console.log(chalk.magenta.bold('    PROXY MASTER - BY XANVERIUS        '));
console.log(chalk.magenta.bold('=============================================='));
console.log(chalk.white(' 1. HTTP | 2. SOCKS4 | 3. SOCKS5 | 4. ALL'));
console.log(chalk.magenta.bold('=============================================='));

rl.question(chalk.yellow('Pilih (1-4): '), (choice) => {
    if (choice === '1') selectedTypes = ['http'];
    else if (choice === '2') selectedTypes = ['socks4'];
    else if (choice === '3') selectedTypes = ['socks5'];
    else if (choice === '4') selectedTypes = ['http', 'socks4', 'socks5'];
    else process.exit();
    startScraping();
});
